from django.contrib import admin

from myApp.models import Emp


# Register your models here.
admin.site.register(Emp)